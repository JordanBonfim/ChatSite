package DAOs;

import Entities.Messages;
import Entities.MessagesPK;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public class DAOMessages extends DAOGenerico<Messages> {

    private List<Messages> lista = new ArrayList<>();

    public DAOMessages() {
        super(Messages.class);
    }

    //    public int autoIdMessages() {
//        Integer a = (Integer) em.createQuery("SELECT MAX(e.idMessage) FROM Messages e ").getSingleResult();
//        
//        if (a != null) {
//            return a + 1;
//        } else {
//            return 1;
//        }
//    }
    public int autoIdMessages() {

        List lista = em.createQuery("SELECT e FROM Messages e").getResultList();
        int a = lista.size();
        if (a != 0) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public Messages obter(MessagesPK messagesPK) {
        return em.find(Messages.class, messagesPK);
    }

    public List<Messages> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Messages e WHERE e.idMessage) LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Messages> listById(int id) {
        return em.createQuery("SELECT e FROM Messages + e WHERE e.idMessage= :id").setParameter("id", id).getResultList();
    }

    public List<Messages> listInOrderNome() {
        return em.createQuery("SELECT e FROM Messages e ORDER BY e.idMessage").getResultList();
    }

    public List<Messages> listInOrderId() {
        return em.createQuery("SELECT e FROM Messages e").getResultList();
    }

//    public List<Messages> listInOrderIdRoom(String userName) {
//        return em.createQuery("SELECT e FROM Messages e WHERE e.room_idRoom LIKE :userName").setParameter("userName", userName).getResultList();
//    }
    public List<Messages> listInOrderIdRoom(String userName) {
        return em.createQuery("SELECT e FROM Messages e").getResultList();
    }

//
//    public List<Messages> listInOrderId() {
//        List<Messages> list = em.createQuery("select u.balance from Users u where u.userName = '" + user_name.getText() +"'", Integer.class).getResultList();
//        System.out.println(list);
//        return list;
//    }
//    public static void saveLogin() {
//        em.createQuery("INSERT INTO users (\"userName\", \"userPassword\")\n" +
//"values ('Jordan','teste');").getResultList();
//    }
    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Messages> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
//            ls.add(lf.get(i).getIdMessage()+ ";" + lf.get(i).getText());
            ls.add(lf.get(i).getMessagesPK().toString());
        }
        return ls;
    }

    public List<String> listMessages(String qualOrdem, String userName, int idRoom) {
        SimpleDateFormat simpleFormat = new SimpleDateFormat("dd/MM/yyyy");
        simpleFormat.setTimeZone(TimeZone.getTimeZone("Brazil/East"));
        String dateNow = simpleFormat.format(Calendar.getInstance().getTime());
        List<Messages> lf;
        switch (qualOrdem) {
            case "id":
                lf = listInOrderId();
                break;
            case "room":
                lf = listInOrderIdRoom(userName);
                break;
            default:
                lf = listInOrderNome();
                break;
        }
        String msgContent;

        List<String> ls = new ArrayList<>();

        for (Messages mensagem : lf) {

            MessagesPK msgPk;
            msgPk = mensagem.getMessagesPK();

            if (msgPk.getRoomidRoom() == idRoom) {
                msgContent = mensagem.getContent();
                String msgDecrypted = descriptografar(msgContent, 8);
                try {
                    if (mensagem.getSentTime().contains(dateNow)) {
                        int length = mensagem.getSentTime().length();
                        String hour = mensagem.getSentTime().substring(11, length);
                        ls.add(hour + " - " + mensagem.getMessagesPK().getUsersuserName() + ": " + msgDecrypted);
                    } else {
                        ls.add(mensagem.getSentTime() +" - "+ mensagem.getUsers().getUserName() + ": " + msgDecrypted);
                    }
                } catch (Exception e) {
                    System.out.println(e);
                    System.out.println("Erro");
                }
            }
        }
        return ls;
    }

    public static String descriptografar(String msgCript, int chave) {
        String msg = "";
        for (int i = 0; i < msgCript.length(); i++) {
            msg += (char) (msgCript.charAt(i) - chave);
        }
        return msg;
    }
//    public List<String> simpleList() {
//        DAOMessages daoMessages = new DAOMessages();
//        List<Messages> ls = daoMessages.list();
//        List<String> listaMessages = null;
//        for (Messages user : ls) {
//            System.out.println(user.getUserName()+ "-" + user.getUserPassword());
//            listaMessages.add(user.getUserName());
//            listaMessages.add(user.getUserPassword());
//
//        }
//        return listaMessages;
//    }

    public static void main(String[] args) {
        DAOMessages daoMessages = new DAOMessages();
        List<Messages> listaMessages = daoMessages.list();

        for (Messages user : listaMessages) {
//            System.out.println(user.getIdMessage()+ "-" + user.getContent());
            System.out.println("-" + user.getContent());
        }
    }
}
