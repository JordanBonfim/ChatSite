package DAOs;

import static DAOs.DAOGenerico.em;
import Entities.Room;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DAORooms extends DAOGenerico<Room> {

    private List<Room> lista = new ArrayList<>();

    public DAORooms() {
        super(Room.class);
    }

   //    public int autoIdMessages() {
//        Integer a = (Integer) em.createQuery("SELECT MAX(e.idMessage) FROM Messages e ").getSingleResult();
//        
//        if (a != null) {
//            return a + 1;
//        } else {
//            return 1;
//        }
//    }
    public int autoIdRoom() {
        List<Room> lista =  em.createQuery("SELECT e FROM Room e").getResultList();
        System.out.println("Lista: "+ lista);
        int counter = 0;
        int id = 0;
        int a = lista.size();
        System.out.println("Quantidade (lista.size() ):  " + a);
        while(true){
            try {
                id = lista.get(counter).getIdRoom();
                System.out.println("id: "+ id);
            } catch (Exception e) {
                id = counter+1;
                return id;
            }
            counter++;
        }
        
//        if (a != 0) {
//            return a + 1;
//        } else {
//            return 1;
//        }
    }

    public List<Room> getSingleRoom(String nome) {
        return em.createQuery("SELECT e FROM Room e WHERE e.roomName LIKE :nome").setParameter("nome",nome).getResultList();
    }
    
    public List<Room> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Room e WHERE e.idRoom) LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Room> listById(int id) {
        return em.createQuery("SELECT e FROM Room + e WHERE e.idRoom= :id").setParameter("id", id).getResultList();
    }

    public List<Room> listInOrderNome() {
        return em.createQuery("SELECT e FROM Room e").getResultList();
    }

    public List<Room> listInOrderId() {
        return em.createQuery("SELECT e FROM Room e").getResultList();
    }
    
    public List<Room> listUsersRooms(String username) {
        List<Room> ls = em.createQuery("SELECT e FROM room_has_users e WHERE users_userName=\""+username+"\" ").getResultList();
        System.out.println("AQui os gruporsss: "+ls);
        
        return em.createQuery("SELECT e FROM Room e").getResultList();
    }


    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Room> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }
        System.out.println("teste"+lf);
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdRoom()+ ";" + lf.get(i).getNameRoom());
//            ls.add(lf.get(i).getNameGroup());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAORooms daoRoom = new DAORooms();
        List<Room> listaRooms = daoRoom.listInOrderNome();

        for (Room room : listaRooms) {
//            System.out.println(user.getIdMessage()+ "-" + user.getContent());
            System.out.println("Nome Grupo: " + room.getNameRoom()+ daoRoom.listUsersRooms("jordan"));
        }
    }
}
