package DAOs;

import Entities.Room;
import Entities.UsersHasRoom;
import java.util.ArrayList;
import java.util.List;

public class DAOUsersHasRoom extends DAOGenerico<UsersHasRoom> {

    private List<UsersHasRoom> lista = new ArrayList<>();

    public DAOUsersHasRoom() {
        super(UsersHasRoom.class);
    }

    public int autoIdUsers() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.userName) FROM Users e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    //em.createNativeQuery("INSERT INTO testtable ('column1','column2') VALUES ('test1','test2')").executeUpdate();
    public int insert(String nome, int room_idRoom, short isAdmin) {
//        String query = "insert into u496940340_chat.users_has_room values(jorda,4,1)";
//INSERT INTO `u496940340_chat`.`users_has_room` (`users_userName`, `room_idRoom`, `isAdmin`) VALUES ('jordan', '4', '1');
        DAOUsersHasRoom daoUsersHasRoom = new DAOUsersHasRoom();
        List<UsersHasRoom> listaUsersHasRoom = daoUsersHasRoom.list();
        List<UsersHasRoom> aux = new ArrayList();

        for (UsersHasRoom usersHasRoomAux : listaUsersHasRoom) {
            if (usersHasRoomAux.getRoom().getIdRoom() == room_idRoom && usersHasRoomAux.getUsersHasRoomPK().getUsersuserName().equals(nome)) {
                aux.add(usersHasRoomAux);
            }
        }

        if (aux.size() > 0) {
            return 2;
        } else {
            String query = "INSERT INTO `u496940340_chat`.`users_has_room` (`users_userName`, `room_idRoom`, `isAdmin`) VALUES ('" + nome + "', '" + room_idRoom + "', '" + isAdmin + "')";
            try {
                em.getTransaction().begin();
                em.createNativeQuery(query).executeUpdate();
                em.getTransaction().commit();
                return 0;
            } catch (Exception exception) {
                System.out.println("Error executing a query");
                em.getTransaction().rollback();
                return 1;
            }

        }
    }

    public int removeUserFromGroup(String nome, int room_idRoom) {
        //SELECT * FROM users_has_room WHERE users_userName LIKE "craco" AND room_idRoom LIKE 1
        //em.createQuery("SELECT e FROM Users e WHERE e.userName LIKE :nome").setParameter("nome", nome).getResultList();
        //Object lista = em.createQuery("SELECT e FROM users_has_room WHERE e.users_userName LIKE :nome AND e.room_idRoom LIKE :room_idRoom").getSingleResult();
        //if (lista.size() > 0) {
        //List<UsersHasRoom> listaUsersHasRoom = daoUsersHasRoom.list();
        //List<UsersHasRoom> lista = em.createQuery("SELECT e FROM users_has_room e").getResultList();

        DAOUsersHasRoom daoUsersHasRoom = new DAOUsersHasRoom();
        List<UsersHasRoom> listaUsersHasRoom = daoUsersHasRoom.list();
        List<UsersHasRoom> aux = new ArrayList();

        for (UsersHasRoom usersHasRoomAux : listaUsersHasRoom) {
            if (usersHasRoomAux.getRoom().getIdRoom() == room_idRoom && usersHasRoomAux.getUsersHasRoomPK().getUsersuserName().equals(nome)) {
                aux.add(usersHasRoomAux);
            }
        }

        if (aux.size() < 1) {
            return 2;
        } else {

            String query = "DELETE FROM `u496940340_chat`.`users_has_room` WHERE (`users_userName` = '" + nome + "') and (`room_idRoom` = '" + room_idRoom + "')";
            try {
                em.getTransaction().begin();
                em.createNativeQuery(query)
                        .executeUpdate();
                em.getTransaction().commit();
                return 0;
            } catch (Exception e) {
                System.out.println("Error executing a query");
                em.getTransaction().rollback();
                return 1;
            }
        }
    }

    public List<UsersHasRoom> getSingleUser(String nome) {
        return em.createQuery("SELECT e FROM Users e WHERE e.userName LIKE :nome").setParameter("nome", nome).getResultList();
    }

    public List<UsersHasRoom> getUserRooms(String nome) {
        return em.createQuery("SELECT e FROM UsersHasRoom e WHERE e.users_userName LIKE :nome").setParameter("nome", nome).getResultList();
    }

    public List<UsersHasRoom> listByEmail(String email) {
        return em.createQuery("SELECT e FROM Users e WHERE e.userEmail LIKE :email").setParameter("email", "%" + email + "%").getResultList();
    }

    public List<UsersHasRoom> listById(int id) {
        return em.createQuery("SELECT e FROM Users + e WHERE e.userName= :id").setParameter("id", id).getResultList();
    }

    public List<UsersHasRoom> listInOrderNome() {
        return em.createQuery("SELECT e FROM Users e ORDER BY e.userName").getResultList();
    }

    public List<UsersHasRoom> listInOrderId() {
        return em.createQuery("SELECT e FROM Users e ORDER BY e.userName").getResultList();
    }

//    public static void saveLogin() {
//        em.createQuery("INSERT INTO users (\"userName\", \"userPassword\")\n" +
//"values ('Jordan','teste');").getResultList();
//    }
    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<UsersHasRoom> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
//            ls.add(lf.get(i).getUserName()+ ";" + lf.get(i).getUserPassword());
        }
        return ls;
    }

    public List<String> simpleList() {
        DAOUsersHasRoom daoUsers = new DAOUsersHasRoom();
        List<UsersHasRoom> ls = daoUsers.list();
        List<String> listaUsers = null;
        for (UsersHasRoom usersHasRoom : ls) {
//            System.out.println(usersHasRoom.getUserName()+ "-" + usersHasRoom.getUserPassword());
//            listaUsers.add(usersHasRoom.getUserName());
//            listaUsers.add(usersHasRoom.getUserPassword());
        }
        return listaUsers;
    }

    public List<UsersHasRoom> listUsersHasRoom(String name) {
        DAOUsersHasRoom daoUsersHasRoom = new DAOUsersHasRoom();
        List<UsersHasRoom> listaUsersHasRoom = daoUsersHasRoom.list();
        List<UsersHasRoom> listaDeSalas = new ArrayList();
        System.out.println("-0-=-=-=-=-=");
        System.out.println("=-=-=-=-=-");
        System.out.println("Lista de Salas");
        int c = 0;
        for (UsersHasRoom usersHasRoom : listaUsersHasRoom) {
//            System.out.println("UserHasdRoom: "+usersHasRoom);
            if (usersHasRoom.getUsersHasRoomPK().getUsersuserName().equals(name)) {

                listaDeSalas.add(usersHasRoom);
                System.out.println(listaDeSalas.get(c));
                c = c + 1;
            }
        }
        return listaDeSalas; //alterar depois
    }
//
//    public void insertUserHasRoomIntoBD() {
//        String DB_URL = "jdbc:mysql://localhost/bd_chat_5_2";
//        try {
//            Connection conn = DriverManager.getConnection(DB_URL, "root", "!RooT258794613");
//            Statement stmt = conn.createStatement();
//
//            String sql = "INSERT INTO bd_chat_5_2.room VALUES (jordan, '3', '1')";
//
//            stmt.executeUpdate(sql);
//        } catch (Exception e) {
//        }
//    }

    public static void main(String[] args) {
        DAOUsersHasRoom daoUsersHasRoom = new DAOUsersHasRoom();

        Room sala = new Room();
        DAORooms daoRoom = new DAORooms();
        List<Room> ls;
        ls = daoRoom.listInOrderId();
        sala = ls.get(0);

//        List<UsersHasRoom> listaUsersHasRoom = daoUsersHasRoom.getUserRooms("jordan");
        List<UsersHasRoom> listaUsersHasRoom = daoUsersHasRoom.listUsersHasRoom("jordan");

        for (UsersHasRoom usersHasRoom : listaUsersHasRoom) {
//            System.out.println("User: "+usersHasRoom.getUserName()+ " password: " + user.getUserPassword());
        }
    }
}
