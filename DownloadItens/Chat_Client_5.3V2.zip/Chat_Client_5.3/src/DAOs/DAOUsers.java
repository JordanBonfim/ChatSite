package DAOs;

import Entities.Users;
import java.util.ArrayList;
import java.util.List;

public class DAOUsers extends DAOGenerico<Users> {

    private List<Users> lista = new ArrayList<>();

    public DAOUsers() {
        super(Users.class);
    }

    public int autoIdUsers() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.userName) FROM Users e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Users> getSingleUser(String nome) {
        return em.createQuery("SELECT e FROM Users e WHERE e.userName LIKE :nome").setParameter("nome",nome).getResultList();
    }
    

    
   
    public List<Users> listByEmail(String email) {
        return em.createQuery("SELECT e FROM Users e WHERE e.userEmail LIKE :email").setParameter("email", "%" + email + "%").getResultList();
    }

    public List<Users> listById(int id) {
        return em.createQuery("SELECT e FROM Users + e WHERE e.userName= :id").setParameter("id", id).getResultList();
    }

    public List<Users> listInOrderNome() {
        return em.createQuery("SELECT e FROM Users e ORDER BY e.userName").getResultList();
    }

    public List<Users> listInOrderId() {
        return em.createQuery("SELECT e FROM Users e ORDER BY e.userName").getResultList();
    }
    
//    public static void saveLogin() {
//        em.createQuery("INSERT INTO users (\"userName\", \"userPassword\")\n" +
//"values ('Jordan','teste');").getResultList();
//    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Users> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getUserName()+ ";" + lf.get(i).getUserPassword());
        }
        return ls;
    }
    
    public List<String> simpleList() {
        DAOUsers daoUsers = new DAOUsers();
        List<Users> ls = daoUsers.list();
        List<String> listaUsers = null;
        for (Users user : ls) {
            System.out.println(user.getUserName()+ "-" + user.getUserPassword());
            listaUsers.add(user.getUserName());
            listaUsers.add(user.getUserPassword());

        }
        return listaUsers;
    }

    public static void main(String[] args) {
        DAOUsers daoUsers = new DAOUsers();
        List<Users> listaUsers = daoUsers.list();

        for (Users user : listaUsers) {
            System.out.println("User: "+user.getUserName()+ " password: " + user.getUserPassword());
        }
    }
}
