/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author falec
 */
@Entity
@Table(name = "users_has_room")
@NamedQueries({
    @NamedQuery(name = "UsersHasRoom.findAll", query = "SELECT u FROM UsersHasRoom u")})
public class UsersHasRoom implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UsersHasRoomPK usersHasRoomPK;
    @Basic(optional = false)
    @Column(name = "isAdmin")
    private short isAdmin;
    @JoinColumn(name = "room_idRoom", referencedColumnName = "idRoom", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Room room;
    @JoinColumn(name = "users_userName", referencedColumnName = "userName", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Users users;

    public UsersHasRoom() {
    }

    public UsersHasRoom(UsersHasRoomPK usersHasRoomPK) {
        this.usersHasRoomPK = usersHasRoomPK;
    }

    public UsersHasRoom(UsersHasRoomPK usersHasRoomPK, short isAdmin) {
        this.usersHasRoomPK = usersHasRoomPK;
        this.isAdmin = isAdmin;
    }

    public UsersHasRoom(String usersuserName, int roomidRoom) {
        this.usersHasRoomPK = new UsersHasRoomPK(usersuserName, roomidRoom);
    }

    public UsersHasRoomPK getUsersHasRoomPK() {
        return usersHasRoomPK;
    }

    public void setUsersHasRoomPK(UsersHasRoomPK usersHasRoomPK) {
        this.usersHasRoomPK = usersHasRoomPK;
    }

    public short getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(short isAdmin) {
        this.isAdmin = isAdmin;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (usersHasRoomPK != null ? usersHasRoomPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UsersHasRoom)) {
            return false;
        }
        UsersHasRoom other = (UsersHasRoom) object;
        if ((this.usersHasRoomPK == null && other.usersHasRoomPK != null) || (this.usersHasRoomPK != null && !this.usersHasRoomPK.equals(other.usersHasRoomPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entities.UsersHasRoom[ usersHasRoomPK=" + usersHasRoomPK + " ]";
    }
    
}
