/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author falec
 */
@Entity
@Table(name = "messages")
@NamedQueries({
    @NamedQuery(name = "Messages.findAll", query = "SELECT m FROM Messages m")})
public class Messages implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected MessagesPK messagesPK;
    @Basic(optional = false)
    @Column(name = "content")
    private String content;
    @Basic(optional = false)
    @Column(name = "sentTime")
    private String sentTime;
    @JoinColumn(name = "room_idRoom", referencedColumnName = "idRoom", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Room room;
    @JoinColumn(name = "users_userName", referencedColumnName = "userName", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Users users;

    public Messages() {
    }

    public Messages(MessagesPK messagesPK) {
        this.messagesPK = messagesPK;
    }

    public Messages(MessagesPK messagesPK, String content, String sentTime) {
        this.messagesPK = messagesPK;
        this.content = content;
        this.sentTime = sentTime;
    }

    public Messages(int idMessage, String usersuserName, int roomidRoom) {
        this.messagesPK = new MessagesPK(idMessage, usersuserName, roomidRoom);
    }

    public MessagesPK getMessagesPK() {
        return messagesPK;
    }

    public void setMessagesPK(MessagesPK messagesPK) {
        this.messagesPK = messagesPK;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSentTime() {
        return sentTime;
    }

    public void setSentTime(String sentTime) {
        this.sentTime = sentTime;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (messagesPK != null ? messagesPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Messages)) {
            return false;
        }
        Messages other = (Messages) object;
        if ((this.messagesPK == null && other.messagesPK != null) || (this.messagesPK != null && !this.messagesPK.equals(other.messagesPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entities.Messages[ messagesPK=" + messagesPK + " ]";
    }
    
}
