/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author falec
 */
@Embeddable
public class UsersHasRoomPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "users_userName")
    private String usersuserName;
    @Basic(optional = false)
    @Column(name = "room_idRoom")
    private int roomidRoom;

    public UsersHasRoomPK() {
    }

    public UsersHasRoomPK(String usersuserName, int roomidRoom) {
        this.usersuserName = usersuserName;
        this.roomidRoom = roomidRoom;
    }

    public String getUsersuserName() {
        return usersuserName;
    }

    public void setUsersuserName(String usersuserName) {
        this.usersuserName = usersuserName;
    }

    public int getRoomidRoom() {
        return roomidRoom;
    }

    public void setRoomidRoom(int roomidRoom) {
        this.roomidRoom = roomidRoom;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (usersuserName != null ? usersuserName.hashCode() : 0);
        hash += (int) roomidRoom;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UsersHasRoomPK)) {
            return false;
        }
        UsersHasRoomPK other = (UsersHasRoomPK) object;
        if ((this.usersuserName == null && other.usersuserName != null) || (this.usersuserName != null && !this.usersuserName.equals(other.usersuserName))) {
            return false;
        }
        if (this.roomidRoom != other.roomidRoom) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entities.UsersHasRoomPK[ usersuserName=" + usersuserName + ", roomidRoom=" + roomidRoom + " ]";
    }
    
}
