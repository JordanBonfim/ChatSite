/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client_Chat;

import java.util.Properties;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.SimpleEmail;
import org.apache.commons.mail.HtmlEmail;



/**
 *
 * @author cjtehc
 */


public class SendEmail {
        
    
    public class BuildAndSendEmail implements Runnable {

        private final String userName;
        private final String userEmail;
        private final String typeEmail;
          
    public BuildAndSendEmail(String userName, String userEmail, String typeEmail) {
        
        this.userName = userName;
        this.userEmail = userEmail;
        this.typeEmail = typeEmail;
          
    }

    @Override
    public void run() {
        String meuEmail = "jordanduzabonfm@gmail.com";
        String minhaSenha = "senha gerada";
    
        HtmlEmail email = new HtmlEmail();
        email.setHostName("smtp.gmail.com");
        email.setSmtpPort(465);
        email.setAuthenticator(new DefaultAuthenticator(meuEmail,minhaSenha));
        email.setSSLOnConnect(true);
        
        
        try {
            email.setFrom(meuEmail);
            if(typeEmail.equals("REGISTER")){
                email.setSubject(userName+"! Bem vindo ao nosso programa de dominar o mundo com java!!");
                email.setHtmlMsg("<html lang=\"pt-BR\">\n" +
"  <div\n" +
"    style=\"\n" +
"      background-color: #333;\n" +
"      color: white;\n" +
"      box-sizing: border-box;\n" +
"      padding: 0;\n" +
"      margin: 0;\n" +
"      font-family: Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;\n" +
"      display: flex;\n" +
"      width: 500px;\n" +
"      height: 300px;\n" +
"      justify-content: center;\n" +
"      flex-wrap: wrap;\n" +
"      padding: 0 20px;\n" +
"    \"\n" +
"  >\n" +
"    <h1>Boas vindas "+userName+"</h1>\n" +
"    <di>\n" +
"      agradecemos pela preferencia do whatsapp web versão 4.3.2 (mais\n" +
"      atualizada)\n" +
"      <br />\n" +
"      <br />\n" +
"      siga-nos no instagram:\n" +
"      <br />\n" +
"      <br />\n" +
"      <b>\n" +
"        <a\n" +
"          href=\"https://www.instagram.com/jordan_djdb/\"\n" +
"          style=\"\n" +
"            text-decoration: none;\n" +
"            color: white;\n" +
"            display: flex;\n" +
"            align-items: center;\n" +
"            height: 20px;\n" +
"          \"\n" +
"        >\n" +
"          <img\n" +
"            src=\"https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/2048px-Instagram_icon.png\"\n" +
"            style=\"max-width: 15px; padding-right: 5px\"\n" +
"          />jordan\n" +
"        </a>\n" +
"      </b>\n" +
"\n" +
"      <br />\n" +
"      <b>\n" +
"        <a\n" +
"          href=\"https://www.instagram.com/cracogabriel/\"\n" +
"          style=\"\n" +
"            text-decoration: none;\n" +
"            color: white;\n" +
"            display: flex;\n" +
"            align-items: center;\n" +
"            height: 20px;\n" +
"          \"\n" +
"        >\n" +
"          <img\n" +
"            src=\"https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/2048px-Instagram_icon.png\"\n" +
"            style=\"max-width: 15px; padding-right: 5px\"\n" +
"          />craco\n" +
"        </a>\n" +
"      </b>\n" +
"    </di>\n" +
"  </div>\n" +
"</html>");
            }else if(typeEmail.equals("RECOVERY")){
                
                
                
                
                email.setSubject("Recuperação de senha solicitada.");
                email.setHtmlMsg(userName+"<h3>Recebemos seu pedido de recuperação de senha para nossa aplicação: CHAT (version 4.3.2)</h3>"
                    + "<p> Esta aqui é sua senha:"+" *** senha. ***");
                
            }
            
            email.addTo(userEmail);
            
            email.send();
            System.out.println("enviado...");
        } catch (Exception e) {
            e.printStackTrace();
        }

      

    }
    }

    public void RecoveryEmail(String userName) { 
        BuildAndSendEmail buildAndSendEmail = new BuildAndSendEmail(userName,"","recovery");
        Thread enviarEmail = new Thread(buildAndSendEmail);
 
    }
    
    public void registerEmail(String userName, String userEmail) {

        BuildAndSendEmail buildAndSendEmail = new BuildAndSendEmail(userName,userEmail,"REGISTER");
        Thread enviarEmail = new Thread(buildAndSendEmail);
        enviarEmail.start();
    }
    
}
