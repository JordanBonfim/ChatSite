package Client_Chat;

import DAOs.DAOMessages;
import DAOs.DAOUsers;
import DAOs.DAORooms;
import DAOs.DAOUsersHasRoom;
import Entities.Room;
import Entities.Messages;
import Entities.MessagesPK;
import Entities.Users;
import Entities.UsersHasRoom;
import javax.print.attribute.standard.Media;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import javax.imageio.ImageIO;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.util.TimeZone;

public class Client_GUI extends JFrame {

    int isAdminGlobal = 0;

    MouseListenerConfirmar mouseListenerConfirmar = new MouseListenerConfirmar();
    MouseListenerCadastrar mouseListenerCadastrar = new MouseListenerCadastrar();
    MouseListenerVoltar mouseListenerVoltar = new MouseListenerVoltar();
    MouseListenerRegistrar mouseListenerRegistrar = new MouseListenerRegistrar();
    MouseListenerAdicionar mouseListenerAdicionar = new MouseListenerAdicionar();
    MouseListenerRemover mouseListenerRemover = new MouseListenerRemover();

    MouseListenerTextField mouseListenerTextField = new MouseListenerTextField();
    EnterPressed enterPressed = new EnterPressed();
    DAOUsers daoUsers = new DAOUsers();
    DAOMessages daoMsg = new DAOMessages();
    DAORooms daoRoom = new DAORooms();
    DAOUsersHasRoom daoUsersHasRoom = new DAOUsersHasRoom();
    Users user = new Users();
    Users currentUser = new Users();
    Messages msg = new Messages();
    MessagesPK msgPK = new MessagesPK();
    java.util.List<String> usersList = new ArrayList();
    java.util.List<String> messagesList = new ArrayList();
    java.util.List<Messages> lastMessage = new ArrayList();
    java.util.List<Room> roomsList = new ArrayList();
    java.util.List<Room> userRoomsList = new ArrayList();
    java.util.List<Users> roomUsersList = new ArrayList();
    CardLayout cardLayout = new CardLayout();
    Room sala = new Room();
    Room currentRoom = new Room();

    int counterSend = 0;

    Container cp;

    int verificador = 0;
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- LABELS

    JLabel lbBackgroundIMG;
    JLabel lbBackgroundIMGCadastro;
    JLabel lbBackgroundIMGLogin;
    JLabel lbBackGroundAdicionar;
    static JLabel lbGifConectando;

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-IMAGES
//    String urlBackground ="https://cjggstorage.s3.sa-east-1.amazonaws.com/ChatFiles/Images/BackGround/loginScreen2.png";
//    String urlIcons ="https://cjggstorage.s3.sa-east-1.amazonaws.com/ChatFiles/Images/BackGround/loginScreen2.png";
    JFrame frameLoading = new JFrame();

//    URL url;
//    URL url1;
//    URL url2;
//    URL url3;
//    URL url4;
//    URL url5;
//    URL url6;
//    URL url7;
//    URL url8;
//    URL url9;
//    URL url10;
//    URL url11;
//    URL url12;
//    URL url13;
//    URL url14;
//    URL url15;
//    URL url16;
//    URL url17;
//    URL url18;
//    URL url19;
//    URL url20;
//
//    
    URL url1 = new URL("https://i.ibb.co/DQBrKqP/bt-Confirmar-Dark.png");
    URL url2 = new URL("https://i.ibb.co/8803FS5/bt-Confirmar-Light.png");
    URL url3 = new URL("https://i.ibb.co/XZFTM4G/bt-Registrar-Dark.png");
    URL url4 = new URL("https://i.ibb.co/dkTzsZn/bt-Registrar-Light.png");
    URL url5 = new URL("https://i.ibb.co/W6s0YXc/bt-Cadastrar-Icon-Dark.png");
    URL url6 = new URL("https://i.ibb.co/Pjgn9fw/bt-Cadastrar-Icon-Light.png");
    URL url7 = new URL("https://i.ibb.co/ZBrDqyN/bt-Voltar-Icon-Dark.png");
    URL url8 = new URL("https://i.ibb.co/qDFd7F4/bt-Voltar-Icon-Light.png");

    URL url9 = new URL("https://i.ibb.co/ZKwMZNY/back-Ground-Enviar-Sem-Botao.png");
//    URL url10 = new URL("https://i.ibb.co/p2KrwN2/login-Screen2.png");
    URL url10 = new URL("https://i.ibb.co/p2KrwN2/login-Screen2.png");
    URL url11 = new URL("https://i.ibb.co/q98FX8t/cadastrar-Screen.png");
    URL url12 = new URL("https://i.ibb.co/ZKwMZNY/back-Ground-Enviar-Sem-Botao.png");
    URL url13 = new URL("https://i.ibb.co/N6jK74x/back-Ground-Enviar.png");
    URL url14 = new URL("https://i.ibb.co/k6B4vPN/btSend.png");
    URL url15 = new URL("https://i.ibb.co/h9gRGDN/back-Ground-Adicionar-New.png");

    URL url16 = new URL("https://i.ibb.co/qRWVRsV/bt-Adicionar-Icon-Dark.png");
    URL url17 = new URL("https://i.ibb.co/G2H0rVY/bt-Adicionar-Icon-Light.png");

    URL url18 = new URL("https://i.ibb.co/TMfpSmW/bt-Remover-Icon-Dark.png");
    URL url19 = new URL("https://i.ibb.co/z5pxLS6/bt-Remover-Icon-Light.png");

    URL url20 = new URL("https://i.ibb.co/wWDXYbt/whatsApp.png");

//    ImageIcon btConfirmarIconDark = new ImageIcon("Graphics/Images/Icons/btConfirmarDark.png");
//    ImageIcon btConfirmarIconLight = new ImageIcon("Graphics/Images/Icons/btConfirmarLight.png");
//    ImageIcon btRegistrarIconDark = new ImageIcon("Graphics/Images/Icons/btRegistrarDark.png");
//    ImageIcon btRegistrarIconLight = new ImageIcon("Graphics/Images/Icons/btRegistrarLight.png");
//    ImageIcon btCadastrarIconDark = new ImageIcon("Graphics/Images/Icons/btCadastrarIconDark.png");
//    ImageIcon btCadastrarIconLight = new ImageIcon("Graphics/Images/Icons/btCadastrarIconLight.png");
//
//    ImageIcon btVoltarIconDark = new ImageIcon("Graphics/Images/Icons/btVoltarIconDark.png");
//    ImageIcon btVoltarIconLight = new ImageIcon("Graphics/Images/Icons/btVoltarIconLight.png");
//    ImageIcon btAdicionarIconDark = new ImageIcon("Graphics/Images/Icons/btAdicionarIconDark.png");
//    ImageIcon btAdicionarIconLight = new ImageIcon("Graphics/Images/Icons/btAdicionarIconLight.png");
//    ImageIcon btRemoverIconDark = new ImageIcon("Graphics/Images/Icons/btRemoverIconDark.png");
//    ImageIcon btRemoverIconLight = new ImageIcon("Graphics/Images/Icons/btRemoverIconLight.png");
//    ImageIcon BackGroundIMG = new ImageIcon("Graphics/Images/BackGround/backGroundEnviarSemBotao.png");
//    ImageIcon BackGroundIMGLogin = new ImageIcon("Graphics/Images/BackGround/loginScreen2.png");
//    ImageIcon BackGroundIMGCadastro = new ImageIcon("Graphics/Images/BackGround/cadastrarScreen.png");
//    ImageIcon BackGroundIMGsemBotao = new ImageIcon("Graphics/Images/BackGround/backGroundEnviarSemBotao.png");
//    ImageIcon BackGroundIMG2digitar = new ImageIcon("Graphics/Images/BackGround/backGroundEnviar.png");
//    ImageIcon backGroundAdicionar = new ImageIcon("Graphics/Images/BackGround/backGroundAdicionarNew.png");
//    ImageIcon btEnviarIcon = new ImageIcon("Graphics/Images/Icons/btSend.png");
    Image btConfirmarIconDarkURL;
    Image btConfirmarIconLightURL;
    ImageIcon btConfirmarIconDark;
    ImageIcon btConfirmarIconLight;

    Image btRegistrarIconDarkURL;
    Image btRegistrarIconLightURL;
    ImageIcon btRegistrarIconDark;
    ImageIcon btRegistrarIconLight;

    Image btCadastrarIconDarkURL;
    Image btCadastrarIconLightURL;
    ImageIcon btCadastrarIconDark;
    ImageIcon btCadastrarIconLight;

    Image btVoltarIconDarkURL;
    Image btVoltarIconLightURL;
    ImageIcon btVoltarIconDark;
    ImageIcon btVoltarIconLight;

    Image btAdicionarIconDarkURL;
    Image btAdicionarIconLightURL;
    ImageIcon btAdicionarIconDark;
    ImageIcon btAdicionarIconLight;

    Image btRemoverIconDarkURL;
    Image btRemoverIconLightURL;
    ImageIcon btRemoverIconDark;
    ImageIcon btRemoverIconLight;

    Image BackGroundIMGURL;
    Image BackGroundIMGLoginURL;
    Image BackGroundIMGCadastroURL;
    Image backGroundEnviarSemBotaoURL;
    Image backGroundEnviarURL;
    Image backGroundAdicionarURL;

    ImageIcon BackGroundIMG;
    ImageIcon BackGroundIMGLogin;
    ImageIcon BackGroundIMGCadastro;
    ImageIcon BackGroundIMGsemBotao;
    ImageIcon BackGroundIMG2digitar;
    ImageIcon backGroundAdicionar;
    Image btEnviarIconURL;
    ImageIcon btEnviarIcon;
    //String pathMp3LoFi = new String("Sound/LoFi.wav");
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-TEXT FIELDS AND TEXT AREAS
    JTextField tfMessageToSend = new JTextField();
    static JTextField tfUserName = new JTextField(20);

    static JTextField tfHiddenId = new JTextField();
    static JTextField tfUserNameCadastrar = new JTextField(20);
    static JTextField tfUserEmailCadastrar = new JTextField(20);

    static JTextField tfUserToAddUsername = new JTextField(20);

    static JPasswordField tfUserPasswordCadastrar = new JPasswordField(20);
    static JPasswordField tfUserPasswordCadastrarConfirmar = new JPasswordField(20);

    static JPasswordField tfUserPassword = new JPasswordField(20);
    static JTextArea taAreaTexto = new JTextArea(10, 20);

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-PANELS
    JPanel name = new JPanel();
    JPanel pnControle = new JPanel(cardLayout);
    JPanel Chat = new JPanel(null);
    JPanel registrar = new JPanel();
    JPanel adicionarMembro = new JPanel();
    JPanel pnloadingPanel = new JPanel();

    static JScrollPane pnScroll = new JScrollPane(taAreaTexto);

    JLabel labelLoading = new JLabel("Carregando arquivos...");
    JLabel labelPerc = new JLabel("");
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-BUTTONS
    JButton btConfirmar = new JButton();
    JButton btRegistrar = new JButton();
    JButton btEnviar = new JButton();
    JButton btVoltar = new JButton();
    JButton btCadastrar = new JButton();
    JButton btAdicionarMembro = new JButton();
    JButton btRemoverMembro = new JButton();

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-CHECKBOX
    JCheckBox cbAddAsAdmin = new JCheckBox("Admin");

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    Popup p;

//LoFi lofi = new LoFi();
    public static void setTextArea(String message, int identifier) {
        JScrollBar vertical = pnScroll.getVerticalScrollBar();
        vertical.setValue(vertical.getMaximum());
        // 145/21831
        int index = message.indexOf("/", 0);
        if (identifier == 1) {
            int idToVerify = 0;
            try {

//            int idToVerify = 0;
//            System.out.println(message);
                idToVerify = Integer.valueOf(message.substring(0, index));
                String messageToAppend = message.substring(index + 1, message.length());
                System.out.println("idToVerify: " + idToVerify);
                System.out.println("tfHiddenId: " + Integer.valueOf(tfHiddenId.getText()));
                if (idToVerify == Integer.valueOf(tfHiddenId.getText())) {
                    taAreaTexto.append(messageToAppend + "\n");
                }
            } catch (Exception e) {
                System.out.println("Deu erro.");
            }

        } else if (identifier == 2) {
//            message=message.substring(3, message.length()-1);
            taAreaTexto.append(message + "\n");
        }

    }

//    public String verifyId(String message) {
//        String privateMessage = message;
//        int index = message.indexOf("/",0);
//        
//        if (index==sala.getIdRoom()) {
//            System.out.println("index: "+index);
//            System.out.println("sala.getIdRoom(): "+ sala.getIdRoom());
//            privateMessage = message.substring(index);
//            return privateMessage;
//        }
//        return null;
//    }
    public static Socket setSocket() throws IOException {
        Socket socket = new Socket("26.181.166.34", 8888);
        return socket;
    }

    /*
    public class LoFi{
        Clip clip;
        public void setFile(String soundFileName){
            try{
                File file = new File(soundFileName);
                AudioInputStream sound = AudioSystem.getAudioInputStream(file);
                clip = AudioSystem.getClip();
                clip.open(sound);


            } catch (UnsupportedAudioFileException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (LineUnavailableException e) {
                e.printStackTrace();
            }
        }
        public void play(){
            clip.setFramePosition(0);
            FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            gainControl.setValue(-20.0f);
            clip.start();
        }

    }
     */
    public class EnterPressed implements ActionListener, KeyListener {

        @Override
        public void actionPerformed(ActionEvent e) {

        }

        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyPressed(KeyEvent e) {

            if (e.getKeyCode() == KeyEvent.VK_ENTER) {

                if (btConfirmar.isVisible()) {
                    System.out.println("confirmar");
                    btConfirmar.doClick();
                } else {
                    System.out.println("Enviar");
                    btEnviar.doClick();
                }
            } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                System.out.println("asd");
            }

        }

        @Override
        public void keyReleased(KeyEvent e) {

        }
    }

    public class MouseListenerConfirmar extends MouseAdapter {

        @Override
        public void mouseEntered(MouseEvent me) {
            btConfirmar.setIcon(btConfirmarIconLight);
        }

        public void mouseExited(MouseEvent me) {
            btConfirmar.setIcon(btConfirmarIconDark);
        }
    }

    public class MouseListenerRemover extends MouseAdapter {

        @Override
        public void mouseEntered(MouseEvent me) {
            btRemoverMembro.setIcon(btRemoverIconLight);
        }

        public void mouseExited(MouseEvent me) {
            btRemoverMembro.setIcon(btRemoverIconDark);
        }
    }

    public class MouseListenerRegistrar extends MouseAdapter {

        @Override
        public void mouseEntered(MouseEvent me) {
            btRegistrar.setIcon(btRegistrarIconLight);

        }

        public void mouseExited(MouseEvent me) {
            btRegistrar.setIcon(btRegistrarIconDark);
        }
    }

    public class MouseListenerVoltar extends MouseAdapter {

        @Override
        public void mouseEntered(MouseEvent me) {
            btVoltar.setIcon(btVoltarIconDark);

        }

        public void mouseExited(MouseEvent me) {
            btVoltar.setIcon(btVoltarIconLight);
        }
    }

    public class MouseListenerCadastrar extends MouseAdapter {

        @Override
        public void mouseEntered(MouseEvent me) {
            btCadastrar.setIcon(btCadastrarIconLight);

        }

        public void mouseExited(MouseEvent me) {
            btCadastrar.setIcon(btCadastrarIconDark);
        }
    }
    //mouseListenerAdicionar

    public class MouseListenerAdicionar extends MouseAdapter {

        @Override
        public void mouseEntered(MouseEvent me) {
            btAdicionarMembro.setIcon(btAdicionarIconLight);

        }

        public void mouseExited(MouseEvent me) {
            btAdicionarMembro.setIcon(btAdicionarIconDark);
        }
    }

    public class MouseListenerTextField extends MouseAdapter {

        @Override
        public void mouseClicked(MouseEvent me) {

        }

        @Override
        public void mousePressed(MouseEvent me) {

        }
    }

    public static String getUsername() {
        return tfUserName.getText();
    }

    public static String getUserPassword() {
        return tfUserPassword.getText();
    }

    public Client_GUI() throws IOException, InterruptedException {

//        JLabel lbLoadingGif;
//        URL gifURL = new URL("https://i.ibb.co/w6nvtN6/Rolling-1s-200px.gif");
//        Image BloadingGif = ImageIO.read(gifURL);
//        ImageIcon loadGifImage = new ImageIcon("Graphics/Images/Icons/gif.gif");
//        
//        lbLoadingGif = new JLabel("",loadGifImage,JLabel.CENTER);
        Socket socket = null;

        int loopC = 1;
        pnloadingPanel.add(labelLoading);

        cp = getContentPane();
        cp.add(pnControle);
        pnControle.add(pnloadingPanel, "LOADING");
        pnControle.add(name, "NAME");
        pnControle.add(Chat, "CHAT");
        pnControle.add(registrar, "REGISTRAR");
        pnControle.add(adicionarMembro, "MEMBRO");
        cardLayout.show(pnControle, "LOADING");

//        pnloadingPanel.add(lbLoadingGif);
        setResizable(false);
        setSize(250, 100);
        setTitle("WhatsApp 5.0");
        setVisible(true);
        setLocationRelativeTo(null);

        labelPerc.setText("0%");
        pnloadingPanel.add(labelPerc);
        btConfirmarIconDarkURL = ImageIO.read(url1);
        btConfirmarIconLightURL = ImageIO.read(url2);
        labelPerc.setText("7.4%");
        btConfirmarIconDark = new ImageIcon(btConfirmarIconDarkURL);
        labelPerc.setText("12%");
        btConfirmarIconLight = new ImageIcon(btConfirmarIconLightURL);
        btRegistrarIconDarkURL = ImageIO.read(url3);
        btRegistrarIconLightURL = ImageIO.read(url4);
        labelPerc.setText("18%");
        btRegistrarIconDark = new ImageIcon(btRegistrarIconDarkURL);
        btRegistrarIconLight = new ImageIcon(btRegistrarIconLightURL);

        btCadastrarIconDarkURL = ImageIO.read(url5);
        labelPerc.setText("25%");
        btCadastrarIconLightURL = ImageIO.read(url6);
        btCadastrarIconDark = new ImageIcon(btCadastrarIconDarkURL);
        btCadastrarIconLight = new ImageIcon(btCadastrarIconLightURL);

        btVoltarIconDarkURL = ImageIO.read(url7);
        btVoltarIconLightURL = ImageIO.read(url8);
        labelPerc.setText("40%");
        btVoltarIconDark = new ImageIcon(btVoltarIconDarkURL);
        btVoltarIconLight = new ImageIcon(btVoltarIconLightURL);

        btAdicionarIconDarkURL = ImageIO.read(url16);
        btAdicionarIconLightURL = ImageIO.read(url17);
        btAdicionarIconDark = new ImageIcon(btAdicionarIconDarkURL);
        labelPerc.setText("47%");
        btAdicionarIconLight = new ImageIcon(btAdicionarIconLightURL);

        btRemoverIconDarkURL = ImageIO.read(url18);
        btRemoverIconLightURL = ImageIO.read(url19);
        btRemoverIconDark = new ImageIcon(btRemoverIconDarkURL);
        btRemoverIconLight = new ImageIcon(btRemoverIconLightURL);

        BackGroundIMGURL = ImageIO.read(url9);
        BackGroundIMGLoginURL = ImageIO.read(url10);
        labelPerc.setText("50%");
        BackGroundIMGCadastroURL = ImageIO.read(url11);
        backGroundEnviarSemBotaoURL = ImageIO.read(url12);
        labelPerc.setText("55%");
        backGroundEnviarURL = ImageIO.read(url13);
        backGroundAdicionarURL = ImageIO.read(url15);
        labelPerc.setText("63%");

        BackGroundIMG = new ImageIcon(BackGroundIMGURL);
        BackGroundIMGLogin = new ImageIcon(BackGroundIMGLoginURL);
        labelPerc.setText("70%");
        BackGroundIMGCadastro = new ImageIcon(BackGroundIMGCadastroURL);
        BackGroundIMGsemBotao = new ImageIcon(backGroundEnviarSemBotaoURL);
        BackGroundIMG2digitar = new ImageIcon(backGroundEnviarURL);
        labelPerc.setText("77%");
        backGroundAdicionar = new ImageIcon(backGroundAdicionarURL);
        btEnviarIconURL = ImageIO.read(url14);
        labelPerc.setText("92.1%");

        btEnviarIcon = new ImageIcon(btEnviarIconURL);
        labelPerc.setText("100%");

        final String SERVER_IP = JOptionPane.showInputDialog(null, "IP do servidor:",
                "Configuração", JOptionPane.QUESTION_MESSAGE);
        try {
            if (SERVER_IP.equals("")) {
                System.exit(0);
            }
        } catch (Exception e) {
            System.exit(0);
        }

        final int SERVER_PORT = 8888;
        while (loopC < 22) {

            if (loopC == 21) {
                System.out.println(" ");
                System.out.println("Nenhuma conexão pôde ser estabelecida...");
                System.exit(0);
            }
            System.out.println("-=-=-=-=-=-=-=-=-=-");
            System.out.print("Tentativa de conexão: " + loopC);

            try {
                socket = new Socket(SERVER_IP, SERVER_PORT);
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                System.out.println("Conectado ao servidor com sucesso!");
                System.out.println(socket);
                break;

            } catch (Exception e) {
                System.out.println("  Falhou...");
                System.out.println(" ");
                Thread.sleep(1000);
                if (loopC < 20) {
                    System.out.println("Tentando novamente em 2 segundos.");
                    Thread.sleep(1000);
                    System.out.println("Tentando novamente em 1 segundo.");
                    Thread.sleep(1000);
                }
            }
            loopC++;

        }
        ServerConnection serverConnection = new ServerConnection(socket);

        new Thread(serverConnection).start();

        //lofi.setFile(pathMp3LoFi);
        //lofi.play();
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-PANELS
        name.setBackground(Color.black);
        registrar.setBackground(Color.black);

        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-BUTTONS
        btEnviar.setSize(40, 40);
        btEnviar.setLocation(542, 400);

        btEnviar.setIcon(btEnviarIcon);
        btEnviar.setBorderPainted(false);
        btEnviar.setBorderPainted(false);
        btEnviar.setFocusPainted(false);
        btEnviar.setContentAreaFilled(false);

        btConfirmar.addMouseListener(mouseListenerConfirmar);
        btConfirmar.setSize(162, 46);
        btConfirmar.setLocation(20, 180);

        btConfirmar.setIcon(btConfirmarIconDark);
        btConfirmar.setBorderPainted(false);
        btConfirmar.setBorderPainted(false);
        btConfirmar.setFocusPainted(false);
        btConfirmar.setContentAreaFilled(false);

        btRegistrar.addMouseListener(mouseListenerRegistrar);
        btRegistrar.setSize(162, 46);
        btRegistrar.setLocation(180, 180);

        btRegistrar.setIcon(btRegistrarIconDark);
        btRegistrar.setBorderPainted(false);
        btRegistrar.setBorderPainted(false);
        btRegistrar.setFocusPainted(false);
        btRegistrar.setContentAreaFilled(false);

        btVoltar.addMouseListener(mouseListenerVoltar);
        btVoltar.setSize(162, 46);
        btVoltar.setLocation(240, 350);

        btVoltar.setIcon(btVoltarIconDark);
        btVoltar.setBorderPainted(false);
        btVoltar.setBorderPainted(false);
        btVoltar.setFocusPainted(false);
        btVoltar.setContentAreaFilled(false);

        btCadastrar.addMouseListener(mouseListenerCadastrar);
        btCadastrar.setSize(162, 46);
        btCadastrar.setLocation(480, 350);

        btCadastrar.setIcon(btCadastrarIconDark);
        btCadastrar.setBorderPainted(false);
        btCadastrar.setBorderPainted(false);
        btCadastrar.setFocusPainted(false);
        btCadastrar.setContentAreaFilled(false);

        btAdicionarMembro.addMouseListener(mouseListenerAdicionar);
        btAdicionarMembro.setSize(162, 46);
        btAdicionarMembro.setLocation(240, 100);

        btAdicionarMembro.setIcon(btAdicionarIconDark);
        btAdicionarMembro.setBorderPainted(false);
        btAdicionarMembro.setBorderPainted(false);
        btAdicionarMembro.setFocusPainted(false);
        btAdicionarMembro.setContentAreaFilled(false);

        //btRemoverIconLight
        btRemoverMembro.addMouseListener(mouseListenerRemover);
        btRemoverMembro.setSize(162, 46);
        btRemoverMembro.setLocation(75, 100);

        btRemoverMembro.setIcon(btRemoverIconDark);
        btRemoverMembro.setBorderPainted(false);
        btRemoverMembro.setBorderPainted(false);
        btRemoverMembro.setFocusPainted(false);
        btRemoverMembro.setContentAreaFilled(false);

        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- LABELS
        lbBackgroundIMGLogin = new JLabel("", BackGroundIMGLogin, JLabel.CENTER);
        lbBackgroundIMGLogin.setBounds(0, 0, 400, 300);
        lbBackgroundIMGLogin.setLayout(null);
        lbBackgroundIMGLogin.add(btConfirmar);
        lbBackgroundIMGLogin.add(btRegistrar);

        lbBackgroundIMGCadastro = new JLabel("", BackGroundIMGCadastro, JLabel.CENTER);
        lbBackgroundIMGCadastro.setBounds(0, 0, 880, 490);
        lbBackgroundIMGCadastro.setLayout(null);
        lbBackgroundIMGCadastro.add(tfUserNameCadastrar);
        lbBackgroundIMGCadastro.add(tfUserEmailCadastrar);
        lbBackgroundIMGCadastro.add(tfUserPasswordCadastrar);
        lbBackgroundIMGCadastro.add(tfUserPasswordCadastrarConfirmar);
        lbBackgroundIMGCadastro.add(btCadastrar);
        lbBackgroundIMGCadastro.add(btVoltar);

        lbBackGroundAdicionar = new JLabel("", backGroundAdicionar, JLabel.CENTER);
        lbBackGroundAdicionar.setBounds(0, 0, 530, 382);
        lbBackGroundAdicionar.setLayout(null);
        lbBackGroundAdicionar.add(tfUserToAddUsername);
        lbBackGroundAdicionar.add(cbAddAsAdmin);
        lbBackGroundAdicionar.add(btAdicionarMembro);
        lbBackGroundAdicionar.add(btRemoverMembro);

        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-TEXT FIELDS AND TEXT AREAS
        taAreaTexto.setEditable(false);
        tfMessageToSend.addMouseListener(mouseListenerTextField);

        tfUserNameCadastrar.setSize(245, 30);
        tfUserNameCadastrar.setLocation(408, 120);
        tfUserNameCadastrar.setOpaque(false);
        tfUserNameCadastrar.setBorder(null);
        tfUserNameCadastrar.setForeground(Color.WHITE);

        tfUserEmailCadastrar.setSize(245, 30);
        tfUserEmailCadastrar.setLocation(408, 171);
        tfUserEmailCadastrar.setOpaque(false);
        tfUserEmailCadastrar.setBorder(null);
        tfUserEmailCadastrar.setForeground(Color.WHITE);

        tfUserPasswordCadastrar.setSize(245, 30);
        tfUserPasswordCadastrar.setLocation(408, 220);
        tfUserPasswordCadastrar.setOpaque(false);
        tfUserPasswordCadastrar.setBorder(null);
        tfUserPasswordCadastrar.setForeground(Color.WHITE);

        tfUserPasswordCadastrarConfirmar.setSize(245, 30);
        tfUserPasswordCadastrarConfirmar.setLocation(408, 268);
        tfUserPasswordCadastrarConfirmar.setOpaque(false);
        tfUserPasswordCadastrarConfirmar.setBorder(null);
        tfUserPasswordCadastrarConfirmar.setForeground(Color.WHITE);

        tfUserName.setSize(173, 19);
        tfUserName.setLocation(201, 68);
        tfUserName.setOpaque(false);
        tfUserName.setBorder(null);
        lbBackgroundIMGLogin.add(tfUserName);
        tfUserName.addKeyListener(enterPressed);

        tfUserPassword.setSize(173, 19);
        tfUserPassword.setLocation(201, 110);
        tfUserPassword.setOpaque(false);
        tfUserPassword.setBorder(null);
        lbBackgroundIMGLogin.add(tfUserPassword);

        tfUserPassword.addKeyListener(enterPressed);

        tfUserToAddUsername.setSize(171, 22);
        tfUserToAddUsername.setLocation(277, 43);
        tfUserToAddUsername.setOpaque(false);
        tfUserToAddUsername.setBorder(null);
        tfUserToAddUsername.setForeground(Color.WHITE);
        tfUserToAddUsername.setCaretColor(Color.WHITE);

        cbAddAsAdmin.setSize(171, 22);
        cbAddAsAdmin.setLocation(277, 63);
        cbAddAsAdmin.setOpaque(false);
        cbAddAsAdmin.setBorder(null);
        cbAddAsAdmin.setForeground(Color.WHITE);
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=
        name.add(lbBackgroundIMGLogin);
        registrar.add(lbBackgroundIMGCadastro);
        adicionarMembro.add(lbBackGroundAdicionar);
        name.setLayout(null);
        registrar.setLayout(null);
        adicionarMembro.setLayout(null);

        cardLayout.show(pnControle, "NAME");
        Socket finalSocket2 = socket;
        btConfirmar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                java.util.List<Users> userListed = new ArrayList();

                if (tfUserName.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Nome de usuário vazio.", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (tfUserPassword.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Senha vazia.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    PrintWriter out = null;

                    String userName = tfUserName.getText();
                    String userPass = tfUserPassword.getText();
                    userListed = daoUsers.getSingleUser(userName);
                    System.out.println(userListed);

                    if (userListed.size() > 0
                            && userListed.get(0).getUserName().equals(userName)
                            && userListed.get(0).getUserPassword().equals(userPass)) {
                        try {
                            out = new PrintWriter(finalSocket2.getOutputStream(), true);
                            out.println(tfUserName.getText() + " entrou no chat!");
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                        try {
                            ClientMain.execChatClient(1, null);
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        } catch (InterruptedException interruptedException) {
                            interruptedException.printStackTrace();
                        }

                        try {
                            currentUser.setUserName(userName);
//                            currentUser.set

                            execChat();

                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        } catch (InterruptedException interruptedException) {
                            interruptedException.printStackTrace();
                        }

//                        messagesList = daoMsg.listMessages("id");
//
//                        System.out.println(messagesList);
//                        for (String message : messagesList) {
//                            out.println(message);
//                            System.out.println(message);
//                        }
                        buildMenu();

                    } else {
                        JOptionPane.showMessageDialog(null, "Login Inválido", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                }
            }
        });

        Socket finalSocket = socket;
        btEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Sala selecionada: " + sala);
                SimpleDateFormat simpleFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");

                simpleFormat.setTimeZone(TimeZone.getTimeZone("Brazil/East"));
                TimeZone.setDefault(simpleFormat.getTimeZone());
                String sentTime = simpleFormat.format(Calendar.getInstance().getTime());

                Messages msg = new Messages();
                MessagesPK msgPK = new MessagesPK();

                if (tfMessageToSend.getText().trim().equals("") == false && tfMessageToSend.getText().length() <= 65) {
                    PrintWriter out = null;
                    try {
                        out = new PrintWriter(finalSocket.getOutputStream(), true);
                    } catch (IOException ioException) {
                        JOptionPane.showMessageDialog(null, "Servidor foi fechado! Conexão encerrada.", "Error", JOptionPane.ERROR_MESSAGE);
                        ioException.printStackTrace();
                    }
                    int length = sentTime.length();
                    String hour = sentTime.substring(11, length);
                    out.println(sala.getIdRoom() + "/" + hour + " - " + tfUserName.getText() + ": " + tfMessageToSend.getText());
                    int idMessage = daoMsg.autoIdMessages();
                    lastMessage = daoMsg.listInOrderId();
                    try {
                        msgPK.setRoomidRoom(sala.getIdRoom());
                        msgPK.setUsersuserName(tfUserName.getText());
                        msgPK.setIdMessage(idMessage);
                        msg.setSentTime(sentTime);
                        msg.setMessagesPK(msgPK);
                        String msgCrypted = criptografar(tfMessageToSend.getText(), 8);
                        msg.setContent(msgCrypted);
                        System.out.println(msg);
                        System.out.println("MSG: " + msg);
                        daoMsg.atualizar(msg);
                    } catch (Exception exception) {
                        JOptionPane.showMessageDialog(null,
                                "Selecione um grupo antes de enviar mensagens.",
                                "Aviso",
                                JOptionPane.WARNING_MESSAGE);
                        System.out.println(exception);
                    }
                }
                tfMessageToSend.setText("");
                tfMessageToSend.requestFocus();
            }
        });

        Socket finalSocket3 = socket;
        btRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setSize(880, 520);
                setLocationRelativeTo(null);
                cardLayout.show(pnControle, "REGISTRAR");
            }
        });

        btCadastrar.addActionListener(new ActionListener() {
            Users user = new Users();
            java.util.List<Users> userList = new ArrayList();
            java.util.List<Users> userList2 = new ArrayList();

            @Override
            public void actionPerformed(ActionEvent e) {
                SendEmail sendEmail = new SendEmail();
                int verifier = 0;
                if (tfUserNameCadastrar.getText().length() > 20) {
                    tfUserNameCadastrar.setText("");
                    JOptionPane.showMessageDialog(null, "Username deve ser menor que 20", "Error", JOptionPane.ERROR_MESSAGE);
                    verifier++;
                } else if (tfUserNameCadastrar.getText().trim().equals("")) {
                    tfUserNameCadastrar.setText("");
                    JOptionPane.showMessageDialog(null, "UserName não pode ser vazio", "Error", JOptionPane.ERROR_MESSAGE);
                    verifier++;
                } else if (tfUserEmailCadastrar.getText().trim().equals("")) {
                    tfUserEmailCadastrar.setText("");
                    JOptionPane.showMessageDialog(null, "Email não pode ser vazio", "Error", JOptionPane.ERROR_MESSAGE);
                    verifier++;
                } else if (tfUserEmailCadastrar.getText().contains("@") == false || tfUserEmailCadastrar.getText().contains(".com") == false) {
                    tfUserEmailCadastrar.setText("");
                    JOptionPane.showMessageDialog(null, "Email inválido", "Error", JOptionPane.ERROR_MESSAGE);
                    verifier++;
                } else if (tfUserPasswordCadastrar.getText().length() > 20) {
                    tfUserPasswordCadastrar.setText("");
                    JOptionPane.showMessageDialog(null, "Senha deve ser menor que 20", "Error", JOptionPane.ERROR_MESSAGE);
                    verifier++;
                } else if (tfUserPasswordCadastrar.getText().trim().equals("")) {
                    tfUserPasswordCadastrar.setText("");
                    JOptionPane.showMessageDialog(null, "Senha não pode ser vazia", "Error", JOptionPane.ERROR_MESSAGE);
                    verifier++;
                }

                if (verifier == 0) {
                    if (tfUserPasswordCadastrar.getText().equals(tfUserPasswordCadastrarConfirmar.getText())) {
                        user.setUserName(tfUserNameCadastrar.getText());
                        user.setUserPassword(tfUserPasswordCadastrar.getText());
                        user.setUserEmail(tfUserEmailCadastrar.getText());
                        userList = daoUsers.getSingleUser(tfUserNameCadastrar.getText());
                        userList2 = daoUsers.listByEmail(tfUserEmailCadastrar.getText());
                        System.out.println(userList);
                        System.out.println(userList2);

                        if (userList.size() > 0) {
                            JOptionPane.showMessageDialog(null, "Nome de usuário já cadastrado", "Erro!", JOptionPane.ERROR_MESSAGE);
                        } else if (userList2.size() > 0) {
                            JOptionPane.showMessageDialog(null, "Email já cadastrado", "Erro!", JOptionPane.ERROR_MESSAGE);
                        } else {
                            daoUsers.atualizar(user);
                            JOptionPane.showMessageDialog(null, "Usuário cadastrado", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
                            btVoltar.doClick();
                            sendEmail.registerEmail(tfUserNameCadastrar.getText(), tfUserEmailCadastrar.getText());
                            tfUserNameCadastrar.setText("");
                            tfUserEmailCadastrar.setText("");
                            tfUserPasswordCadastrar.setText("");
                            tfUserPasswordCadastrarConfirmar.setText("");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Senhas não coincidem", "Erro!", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });

        btAdicionarMembro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                short isLocalAdmin = 0;
                if (cbAddAsAdmin.isSelected()) {
                    isLocalAdmin = 1;
                } else {
                    isLocalAdmin = 0;
                }

                if (tfUserToAddUsername.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Nome de usuário vazio!", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    int responseVerifier = daoUsersHasRoom.insert(tfUserToAddUsername.getText(), currentRoom.getIdRoom(), isLocalAdmin);

                    switch (responseVerifier) {
                        case 0:
                            JOptionPane.showMessageDialog(null, "Membro adicionado!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                            break;
                        case 1:
                            JOptionPane.showMessageDialog(null, "Erro ao adicionar membro!", "Error", JOptionPane.ERROR_MESSAGE);
                            break;
                        case 2:
                            JOptionPane.showMessageDialog(null, "Membro já pertence ao grupo", "Erro", JOptionPane.INFORMATION_MESSAGE);
                            break;
                    }
                    tfUserToAddUsername.setText("");
                    cbAddAsAdmin.setSelected(false);
                }
            }
        });

        btRemoverMembro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                int response = -1;
                if (tfUserToAddUsername.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Nome de usuário vazio!", "Error", JOptionPane.ERROR_MESSAGE);
                } else {

                    response = daoUsersHasRoom.removeUserFromGroup(tfUserToAddUsername.getText(), currentRoom.getIdRoom());

                    switch (response) {
                        case 0:
                            JOptionPane.showMessageDialog(null, "Membro removido!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                            break;
                        case 1:
                            JOptionPane.showMessageDialog(null, "Erro ao remover membro!", "Error", JOptionPane.ERROR_MESSAGE);
                            break;
                        case 2:
                            JOptionPane.showMessageDialog(null, "Membro já não pertence ao grupo", "Erro", JOptionPane.INFORMATION_MESSAGE);
                            break;
                    }

//                        if (response == 0) {
//                            JOptionPane.showMessageDialog(null, "Membro já não pertence ao grupo", "Erro", JOptionPane.INFORMATION_MESSAGE);
//                        } else if (response == 1) {
//                            JOptionPane.showMessageDialog(null, "Membro removido!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
//
//                        }
                    tfUserToAddUsername.setText("");
                    cbAddAsAdmin.setSelected(false);
                }
            }
        }
        );
        btVoltar.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e
            ) {
                setSize(400, 300);
                setLocationRelativeTo(null);
                cardLayout.show(pnControle, "NAME");
            }
        }
        );

        tfMessageToSend.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae
            ) {
                btEnviar.doClick();
            }
        }
        );

        addWindowListener(
                new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e
            ) {
                for (int i = 0; i < 20; i++) {
                    System.out.println(" ");

                }
                System.out.println("Encerrando conexões e fechando...");

                PrintWriter out = null;
                try {
                    out = new PrintWriter(finalSocket.getOutputStream(), true);
                } catch (IOException ioException) {
                    System.exit(0);
                    ioException.printStackTrace();
                }
                out.println(tfUserName.getText() + " se desconectou");
                System.exit(0);
                dispose();
            }
        }
        );
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Image icon = ImageIO.read(url20);
//        Image icon = Toolkit.getDefaultToolkit().getImage("Graphics/Images/Icons/whatsApp.png");

        setIconImage(icon);

        setTitle(
                "WhatsApp 5.0");
        setResizable(
                false);
        setSize(
                400, 300);
        setLocationRelativeTo(
                null);
        setVisible(
                true);

    }

    public static String criptografar(String msg, int chave) {
        String msgCript = "";
        for (int i = 0; i < msg.length(); i++) {
            msgCript += (char) (msg.charAt(i) + chave);
        }
        return msgCript;
    }
    java.util.List<Room> RoomsListGlobal = new ArrayList<>();
    java.util.List<UsersHasRoom> listaUsersHasRoom = daoUsersHasRoom.listUsersHasRoom(tfUserName.getText());

    public void buildRooms() {
        RoomsListGlobal.clear();
        listaUsersHasRoom = daoUsersHasRoom.listUsersHasRoom(tfUserName.getText());
        System.out.println(" -=-=-=-=");
        System.out.println("listaUsersHasRoom: " + listaUsersHasRoom);
        for (UsersHasRoom aux : listaUsersHasRoom) {
            System.out.println(aux);
            Room sala4 = sala4 = aux.getRoom();
            RoomsListGlobal.add(sala4);
        }
        System.out.println("RoomsListGlobal: " + RoomsListGlobal);
    }

    public void buildMenu() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Grupos");
        JMenuItem updateList = new JMenuItem("Atualizar");
        JMenuItem menuItemCreate = new JMenuItem("Criar Grupo");
        JMenuItem addUser = new JMenuItem("Adicionar membro");
        JMenuItem menuItem;

        roomsList = daoRoom.listInOrderNome();

//        System.out.println("Deveria ser a lista:" + roomsList);
//        userRoomsList=daoRoom.listUsersRooms(tfUserName.getText());
//        Room sala = new Room();
//        sala = daoRoom.obter(1);
//        roomUsersList=sala.getUsersList();
//        
//        System.out.println("Lista de rooms: " + userRoomsList.toString());
//        java.util.List<Users> userListed = new ArrayList();
//        Users usuario = new Users();
//        Room salaa = new Room();
//        String userName = tfUserName.getText();
//        userListed = daoUsers.getSingleUser(userName);
//        usuario = userListed.get(0);
        buildRooms();
        menuBar.add(menu);

        menu.add(updateList);
        menu.add(menuItemCreate);
        menu.addSeparator();

        for (Room room1 : RoomsListGlobal) {
            System.out.println("Sala: " + room1.getNameRoom() + " ;id: " + room1.getIdRoom());
            menuItem = new JMenuItem(room1.getNameRoom());
            menu.add(menuItem);

            menuItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ev) {
                    
                    changeRoom(room1, menu, addUser);
                    cardLayout.show(pnControle, "CHAT");
                    setSize(590, 494);
                    setLocationRelativeTo(null);
                    tfMessageToSend.requestFocus();

                }
            });
        }

        addUser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                cardLayout.show(pnControle, "MEMBRO");
                setSize(538, 392);
                setLocationRelativeTo(null);
                tfUserToAddUsername.requestFocus();
//                String userNameToAdd = JOptionPane.showInputDialog(null, "Nome do usuário:",
//                        "Adicionar membro", JOptionPane.QUESTION_MESSAGE);
//                daoUsersHasRoom.insert(userNameToAdd, , 0);  
            }
        });

        updateList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                buildRooms();
                int i = -1;
                int itemCount = menu.getItemCount();
                for (int j = 0; j < itemCount; j++) {
                    try {
                    } catch (Exception e) {
                    }
                    menu.remove(0);
                }
//                System.out.println("Menu item count: "+menu.getItemCount());
//                for (int h = 0; h < menu.getItemCount(); h++) {
//                    System.out.println("item: "+menu.getItem(h).getText());
//                    menu.remove(h);
//                }
//                while (true) {
//                    try {
////                        String menuItemToDeleteVerificador = menu.getItem(i).getText();
//                        i=i+1;
//                        System.out.println("Removing: " + menu.getItem(i).getText());
//                        menu.remove(menu.getItem(i));
//                        System.out.println("Removed succesfully ");
//                        System.out.println("  ");
//                    } catch (Exception e) {
//                        System.out.println("Catch on: " + i);
//                        break;
//                    }
//                }
//                
//                for (int j = 0; j < 4; j++) {
//                    System.out.println("  ");
//                }
//                System.out.println("Menu:");
//               
//                int topCounter=-1;
//                
//                while (true) {
//                    topCounter=topCounter+1;
//                    try {
//                        System.out.println(menu.getItem(topCounter));
//                    } catch (Exception e) {
//                        break;
//                    }
//                    
//                }
                menu.add(updateList);
                menu.add(menuItemCreate);
                menu.addSeparator();
                for (Room room5 : RoomsListGlobal) {
                    System.out.println("Sala: " + room5.getNameRoom() + " ;id: " + room5.getIdRoom());
                    JMenuItem menuItem = new JMenuItem(room5.getNameRoom());

                    menu.add(menuItem);

                    menuItem.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent ev) {
                            changeRoom(room5, menu, addUser);
                        }
                    });
                }
                if (isAdminGlobal == 1) {
                    menu.add(addUser);
                }
                cardLayout.show(pnControle, "CHAT");
                setSize(590, 494);
                setLocationRelativeTo(null);
            }
        });

        menuItemCreate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                String string = JOptionPane.showInputDialog(null, "Nome do grupo:",
                        "Criar Grupo", JOptionPane.QUESTION_MESSAGE);
                createGroup(string);
                updateList.doClick();
//                daoUsersHasRoom.insertUserHasRoomIntoBD();
            }
        });

//        System.out.println("TATALTALTAL::   -   "+RoomsList);
        setJMenuBar(menuBar);

    }

    public void changeRoom(Room room1, JMenu menu, JMenuItem addUser) {
        cardLayout.show(pnControle, "CHAT");
        java.util.List<UsersHasRoom> listaUsersHasRoom = daoUsersHasRoom.listUsersHasRoom(tfUserName.getText());
        sala = room1;
        tfHiddenId.setText(String.valueOf(sala.getIdRoom()));
        System.out.println("Sala selecionada: " + sala);
        taAreaTexto.setText(" ");
        int idRoom = room1.getIdRoom();
        for (UsersHasRoom aux2 : listaUsersHasRoom) {
            if (aux2.getUsersHasRoomPK().getRoomidRoom() == idRoom) {
                if (aux2.getIsAdmin() == 1) {
                    menu.add(addUser);
                    isAdminGlobal = 1;
                } else {
                    isAdminGlobal = 0;
                    menu.remove(addUser);
                }
            }
        }
        DAOMessages daoMsg2 = new DAOMessages();
        messagesList = daoMsg2.listMessages("room", tfUserName.getText(), idRoom);
        taAreaTexto.setText("");
        taAreaTexto.append("Conectado em: " + sala.getNameRoom() + "\n");
        for (String message : messagesList) {
            setTextArea(message, 2);
        }
        tfMessageToSend.setText("");
        currentRoom.setIdRoom(idRoom);
        cardLayout.show(pnControle, "CHAT");
    }

    public void createGroup(String groupName) {
        Room sala3 = new Room();
//        Users user1 = new Users();
        System.out.println("user" + user);
//        UsersHasRoom usersHasRoom2 = new UsersHasRoom();
        JMenu menu = new JMenu("Grupos");
        JMenuItem addUser;
        addUser = new JMenuItem("Adicionar membro");
//        java.util.List<UsersHasRoom> listaUsersHasRooms = daoUsersHasRoom.listUsersHasRoom(tfUserName.getText());
//        sala.setUsersHasRoomList(listaUsersHasRooms);
//        short isAdmin = 0;
//        usersHasRoom2.setIsAdmin(isAdmin);
//        
//        usersHasRoom2.setRoom(sala);
//        
//        usersHasRoom2.setUsers(user1);
//        
//        usersHasRoom2.setRoom(sala);
        sala3.setNameRoom(groupName);
        System.out.println("Log: ");
        System.out.println("groupName: " + groupName);

        int idToSave = daoRoom.autoIdRoom();
        short isAdmin = 1;

        sala3.setIdRoom(idToSave);
        daoRoom.inserir(sala3);
        daoUsersHasRoom.insert(currentUser.getUserName(), idToSave, isAdmin);
        changeRoom(sala3, menu, addUser);
//        while (true) {
//            try {
//                sala.setIdRoom(idToSave);
//                daoRoom.inserir(sala);
//                break;
//            } catch (Exception e) {
//                idToSave++;
//            }
//        }

//        System.out.println("-------------");
//        System.out.println(" Log: ");
//        System.out.println("username: " + currentUser.getUserName());
//        System.out.println("idToSave: " + idToSave);
//        System.out.println("isAdmin: " + isAdmin);
//        System.out.println(" ");
//        System.out.println("-------------");
    }

    public void execChat() throws IOException, InterruptedException {

        setLocation(640, 278);
        setTitle("WhatsApp 5.0");

//        for (int i = 0; i < 600; i++) {
//            if (i <= 494) {
//                setSize(i, i);
//            } else {
//                setSize(i, 494);
//            }
//            try {
//                Thread.sleep(1);
//            } catch (InterruptedException interruptedException) {
//                interruptedException.printStackTrace();
//            }
//        }
//        setSize(480,600);
        //648x280
        setSize(590, 494);
        setVisible(true);
        setLocationRelativeTo(null);

        cardLayout.show(pnControle, "CHAT");
//        setSize(480,600);
        cp.setLayout(null);

        lbBackgroundIMG = new JLabel("", BackGroundIMG, JLabel.CENTER);
        lbBackgroundIMG.setBounds(0, 0, 584, 442);

        Thread tfSendVerifier = new Thread() {
            @Override
            public void run() {
                while (true) {
                    try {
                        if (tfMessageToSend.getText().equals("") || tfMessageToSend.getText().equals(null)) {
                            btEnviar.setVisible(false);
                            lbBackgroundIMG.setIcon(BackGroundIMGsemBotao);
                        } else if (tfMessageToSend.isFocusOwner() == true && tfMessageToSend.getText().equals("") == false && tfMessageToSend.getText().equals(null) == false) {
                            btEnviar.setVisible(true);
                            lbBackgroundIMG.setIcon(BackGroundIMG2digitar);
                        }
                    } catch (Exception e) {
                    }
                }
            }
        };

        tfSendVerifier.start();

        Chat.add(lbBackgroundIMG);
        lbBackgroundIMG.add(btEnviar);
        lbBackgroundIMG.add(tfMessageToSend);

        taAreaTexto.setSize(540, 350);
        taAreaTexto.setLocation(20, 20);

        taAreaTexto.setForeground(Color.cyan);

        taAreaTexto.setLineWrap(true);
        taAreaTexto.setOpaque(false);

        pnScroll.setPreferredSize(new Dimension(540, 350));

        pnScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        pnScroll.setOpaque(false);
        pnScroll.getViewport().setOpaque(false);
        pnScroll.setBorder(null);
        pnScroll.setViewportBorder(null);

        lbBackgroundIMG.add(pnScroll);
        pnScroll.setOpaque(false);
        pnScroll.setSize(540, 350);
        pnScroll.setLocation(20, 20);

        tfMessageToSend.setSize(518, 32);
        tfMessageToSend.setLocation(15, 401);
        tfMessageToSend.setCaretColor(Color.cyan);

        tfMessageToSend.setBorder(null);
        tfMessageToSend.setForeground(Color.cyan);
        tfMessageToSend.setOpaque(false);
//        setSize(589, 470);
        setResizable(false);
    }

}
