package Client_Chat;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;


public class ServerConnection extends JFrame implements Runnable {

    private Socket serverSocket;
    private BufferedReader in;
    String message;
    ArrayList<String> messages = new ArrayList<>();

    public ServerConnection(Socket socket) throws IOException {
        serverSocket = socket;
        in = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));


    }


    @Override
    public void run() {

        try {
            while (true) {
                String serverResponse = in.readLine();
                System.out.println(serverResponse);
                if (serverResponse.equals(null) || serverResponse.equals("null")) {
                    break;
                }
                message = serverResponse;


                if (serverResponse.equals(null)==false && serverResponse.equals("")==false ){
                    Client_GUI.setTextArea(serverResponse,1);
                }


            }
        } catch (IOException e) {
            System.out.println("Conexão encerrada...");
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}



