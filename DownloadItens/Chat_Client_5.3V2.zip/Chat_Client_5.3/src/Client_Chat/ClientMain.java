package Client_Chat;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLOutput;
import javax.crypto.NoSuchPaddingException;

public class ClientMain {


    public static void main(String[] args) throws IOException, InterruptedException, NoSuchAlgorithmException, NoSuchPaddingException {


        Client_GUI client_gui = new Client_GUI();


    }

    public static void execChatClient(int sendMessageVerifier, String message) throws IOException, InterruptedException {

        String userName = Client_GUI.getUsername() + ": ";


    }
}
